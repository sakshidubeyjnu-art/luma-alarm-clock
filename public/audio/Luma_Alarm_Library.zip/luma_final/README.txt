LUMA FINAL AUDIO LIBRARY

Sequence: Luma Digital Alarm -> Luma Ringing Alarm -> Rooster at Dawn -> coffee/morning sounds -> nature/calm -> study/focus -> cozy.

All music/ambience tracks shorter than 5 minutes were looped to exactly 5:00.
Short dedicated alarm sounds (Luma Digital Alarm, Luma Ringing Alarm, Dawn Chime, Old-Fashioned Bell) were kept at their original duration rather than being turned into long loops.
Instrumental was already longer than 5 minutes and was kept as supplied.

The numbered filenames preserve the intended order. The names are the final Luma display names.
